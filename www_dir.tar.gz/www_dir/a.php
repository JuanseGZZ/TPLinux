<?php
$servername = "localhost";
$username = "lcars";
$password = "NCC1701D";
$dbname = "ingenieria";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
echo "Conectado exitosamente a la base de datos<br>";

// Ejecutar una consulta simple
$sql = "SELECT * FROM alumnos";
$result = $conn->query($sql);

if ($result === false) {
    // Mostrar el error si falla la consulta
    echo "Error en la consulta: " . $conn->error;
} else {
    if ($result->num_rows > 0) {
        // Mostrar datos si hay resultados
        while($row = $result->fetch_assoc()) {
            echo "Legajo: " . $row["legajo"]. " - Nombre: " . $row["nombres"]. " " . $row["apellido"]. "<br>";
        }
    } else {
        echo "0 resultados";
    }
}

$conn->close();
?>

