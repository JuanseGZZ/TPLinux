echo "<?php phpinfo(); ?>" | sudo tee /www_dir/info.php

