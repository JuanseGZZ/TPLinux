#!/bin/bash

# Función de ayuda
function mostrar_ayuda {
    echo "Uso: backup_full.sh [DIRECTORIO_ORIGEN] [DIRECTORIO_DESTINO]"
    echo "Este script realiza un backup del DIRECTORIO_ORIGEN al DIRECTORIO_DESTINO."
    echo "Los nombres de los archivos de backup incluyen la fecha en formato YYYYMMDD."
    echo "Ejemplo: etc_bkp_20240302.tar.gz"
    echo
    echo "Opciones:"
    echo "  -h       Muestra esta ayuda."
    exit 0
}

# Comprobación de la opción de ayuda
if [[ "$1" == "-h" ]]; then
    mostrar_ayuda
fi

# Comprobación de los argumentos
if [[ $# -ne 2 ]]; then
    echo "Error: Se requieren dos argumentos: [DIRECTORIO_ORIGEN] y [DIRECTORIO_DESTINO]."
    echo "Use -h para ver la ayuda."
    exit 1
fi

# Asignación de variables
DIRECTORIO_ORIGEN=$1
DIRECTORIO_DESTINO=$2

# Verificación de que ambos directorios existen y están montados
if [[ ! -d "$DIRECTORIO_ORIGEN" ]]; then
    echo "Error: El directorio de origen '$DIRECTORIO_ORIGEN' no existe o no está montado."
    exit 1
fi

if [[ ! -d "$DIRECTORIO_DESTINO" ]]; then
    echo "Error: El directorio de destino '$DIRECTORIO_DESTINO' no existe o no está montado."
    exit 1
fi

# Generación del nombre del archivo de backup
FECHA=$(date +%Y%m%d)
NOMBRE_BACKUP=$(basename "$DIRECTORIO_ORIGEN")_bkp_$FECHA.tar.gz

# Creación del archivo de backup
tar -czf "$DIRECTORIO_DESTINO/$NOMBRE_BACKUP" -C "$DIRECTORIO_ORIGEN" .
if [[ $? -eq 0 ]]; then
    echo "Backup de '$DIRECTORIO_ORIGEN' completado en '$DIRECTORIO_DESTINO/$NOMBRE_BACKUP'."
else
    echo "Error: Falló el backup de '$DIRECTORIO_ORIGEN'."
    exit 1
fi

